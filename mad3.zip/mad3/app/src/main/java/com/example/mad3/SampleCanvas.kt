package com.example.mad3  // Make sure this matches your actual package name

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.util.Log
import android.view.View

class SampleCanvas @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    // Override the onDraw method to draw shapes on the canvas
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        // Log statement to check if onDraw is being called
        Log.d("SampleCanvas", "onDraw called")

        // Create a Paint object to set drawing properties
        val paint = Paint()

        // Draw a red circle
        paint.color = Color.RED
        val circleX = 200f
        val circleY = 200f
        val radius = 100f
        canvas.drawCircle(circleX, circleY, radius, paint)

        // Draw a green square
        paint.color = Color.GREEN
        val left = 400f
        val top = 100f
        val right = 600f
        val bottom = 300f
        canvas.drawRect(left, top, right, bottom, paint)

        // Draw a blue ellipse
        paint.color = Color.BLUE
        val ovalLeft = 100f
        val ovalTop = 400f
        val ovalRight = 500f
        val ovalBottom = 600f
        val oval = RectF(ovalLeft, ovalTop, ovalRight, ovalBottom)
        canvas.drawOval(oval, paint)
    }
}
